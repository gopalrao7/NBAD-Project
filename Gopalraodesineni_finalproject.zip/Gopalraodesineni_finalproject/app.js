//importing modules
const express = require('express');
const morgan = require('morgan');
const connectionRoutes = require('./routes/eventRoutes');
const userRoutes = require('./routes/userRoutes');
const mainRoutes = require('./routes/mainRoutes');
const mongooose = require('mongoose');
const methodOverride = require('method-override');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const flash = require('connect-flash');

//creating express application
const app = express();

//configuring of express application
let port = 5000;
let host = 'localhost'
app.set('view engine','ejs');

//connecting to MongoDB database
mongooose.connect('mongodb://localhost:27017/demos', {useNewUrlParser:true, useUnifiedTopology:true})
.then(()=>{
    //starting the server
    app.listen(port, host, () => {
        console.log("Server is running on port :: " + port);
    })
})
.catch(err=>console.log(err.message));

//mount middlware
app.use(
    session({
        secret: "abcdefghijklmnop",
        resave: false,
        saveUninitialized: false,
        store: new MongoStore({mongoUrl: 'mongodb://localhost:27017/demos'}),
        cookie: {maxAge: 60*60*1000}
        })
);
app.use(flash());

app.use((req, res, next) => {
    res.locals.user = req.session.user||null;
    res.locals.userName = req.session.userName||null;
    res.locals.errorMessages = req.flash('error');
    res.locals.successMessages = req.flash('success');
    next();
});

//mounting of middleware
app.use(express.static('public'));
app.use(morgan('tiny'));
app.use(express.urlencoded({extended: true}));
app.use(methodOverride('_method'));

//routes setup
app.use('/', mainRoutes);
app.use('/events', connectionRoutes);
app.use('/users', userRoutes);

app.use((req, res, next)=>{
    let err = new Error("The server cannot locate " + req.url);
    err.status = 404;
    next(err);
});


app.use((err, req, res, next)=>{
    console.log(err.stack);
    if (!err.status) {
        err.status = 500;
        err.message = ("Intenal Server Error");
    }
    res.status(err.status);
    res.render('error', { error: err }); 
    console.log(err.message);
    console.log(err.stack);
});

