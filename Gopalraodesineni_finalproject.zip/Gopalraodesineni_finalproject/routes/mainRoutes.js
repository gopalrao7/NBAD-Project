const express = require('express');
const mainController = require('../controllers/mainController');

const router = express.Router();

router.get('/', mainController.index)

router.get('/contact',mainController.contact)

router.get('/about', mainController.about)

router.get('/address', mainController.address)

module.exports = router;