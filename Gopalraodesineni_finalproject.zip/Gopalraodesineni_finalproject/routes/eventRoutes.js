const express = require('express');
const controller = require('../controllers/eventController');
const {isLoggedIn, isAuthor} = require('../middlewares/auth');
const {validateId} = require('../middlewares/validator');
const {validateEvent, validateResult, isValidRSVP, isUserEvent} = require('../middlewares/validator');

const router = express.Router();

//GET /tournaments: sending all tournaments to the user
router.get('/', controller.index);

//GET /tournaments/new: send html form to create a new event
router.get('/newConnection', isLoggedIn, controller.new);

//POST /tournaments: Create a new event
router.post('/', isLoggedIn, validateEvent, validateResult, controller.create)

//GET /tournaments/:id: Details of a event identified by id
router.get('/:id', validateId, controller.show)

//GET /tournaments/:id/edit: send html form for editing an existing event
router.get('/:id/edit',validateId, isLoggedIn, isAuthor, controller.edit)

//PUT /tournaments/:id: update the event identified by id
router.put('/:id', validateId, isLoggedIn, isAuthor, validateEvent, validateResult, controller.update)

//DELETE /tournaments/:id: delete the event identified by id
router.delete('/:id', validateId, isLoggedIn, isAuthor, controller.delete)

//RSVP for event
router.post('/:id/rsvp', validateId, isLoggedIn, isValidRSVP, isUserEvent, controller.CreateRSVP)

//RSVP Maybe for event
router.post('/:id/rsvpDelete', validateId, isLoggedIn, controller.DeleteRSVP)

module.exports = router;