const { promiseImpl } = require('ejs');
const{body, validationResult} = require('express-validator');
const { DateTime } = require("luxon");
const model = require('../models/event')

//Check if user is a guest
exports.validateId = (req, res, next) => {
    let id = req.params.id;
    //an objectId is a 24-bit Hex string
    if (!id.match(/^[0-9a-fA-F]{24}$/)) {
        let err = new Error('Invalid story id');
        err.status = 400;
        return next(err);
    }
    else {
        next();
    }
};

exports.validateSignUp = [body('firstName', 'First Name cannot be empty').notEmpty().trim().escape(),
body('lastName', 'Last Name cannot be empty').notEmpty().trim().escape(),
body('email', 'Email must be valid').isEmail().trim().escape().normalizeEmail(),
body('password', 'Password must be between 8 to 64 characters').isLength({min:8, max:64})];

exports.validateSignIn = [body('email', 'Email must be valid').isEmail().trim().escape().normalizeEmail(),
body('password', 'Password must be between 8 to 64 characters').isLength({min:8, max:64})];

exports.validateEvent = [body('title', 'Title must be 3 or more characters').isLength({min:3}).trim().escape(),
body('category', 'category must be 3 or more characters').isLength({min:3}).trim().escape(),
body('details', 'Details must be 10 or more characters').isLength({min:10}).trim().escape(),
body('hostname', 'Hostname cannot be empty').notEmpty().trim().escape(),
body('emailID', 'EmailID cannot be empty').notEmpty().trim().escape(),
body('location', 'location cannot be empty').notEmpty().trim().escape(),
body('img', 'image URL cannot be empty').notEmpty().trim().escape(),
body('startDate', 'start Date cannot be empty').notEmpty().trim().custom((value, {req})=>{
    let startDate = req.body.startDate;
    let dateObj = DateTime.fromFormat(startDate, "yyyy-MM-dd");
    if(!dateObj.isValid){
        throw new Error('Start DateTime is not a valid DateTime');
    }
    else{
        let dateNow = DateTime.now().toFormat("yyyy-MM-dd");
        if (req.body.startDate <= dateNow){
            throw new Error('Start DateTime should be after Present DateTime');
        }
        else return true;
    }
}),
body('endDate', 'End Date cannot be empty').notEmpty().trim().custom((value, {req})=>{
    let endDate = req.body.endDate;
    let dateObj = DateTime.fromFormat(endDate, "yyyy-MM-dd");
    if(!dateObj.isValid){
        throw new Error('End DateTime is not a valid DateTime');
    }
    else{
        if (req.body.startDate >= req.body.endDate){
            throw new Error('End DateTime should be greater than Start DateTime');
        }
        else return true;
    }
})
];

exports.validateResult=(req, res, next)=>{
    let errors = validationResult(req);
    if(!errors.isEmpty()){
        errors.array().forEach(error=>{
            req.flash('error', error.msg);
        });
        return res.redirect('back');
    } else{
        return next();
    }
};


exports.isValidRSVP = (req, res, next)=>{
    let status = req.body.status;
    if(status == null)
    {
        req.flash('error', 'RSVP cannot be empty');
        res.redirect('/');
    }
    else{
        status = req.body.status.toUpperCase();
        if(status == 'YES' || status == 'NO' || status == 'MAYBE')
        {
            next();
        } else{
            req.flash('error', 'RSVP can only be YES, NO or MAYBE');
            res.redirect('/');
        }
    }
};

exports.isUserEvent = (req, res, next)=>{
    model.findById(req.params.id)
    .then(result => {
        if(result.creator._id == req.session.user)
        {
            req.flash('error', 'Cannot RSVP to your own event');
            res.redirect('/');
        }
        else {
            next();
        }
    })
    .catch(err => next(err));
};