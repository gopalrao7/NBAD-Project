const model = require('../models/event')
const user = require('../models/user');
const rsvp = require('../models/rsvp');
const session = require('express-session');

//GET /events: sending all events to the user
exports.index = (req, res, next) => {
    model.find()
        .then(events => {
            let cat = [];
            events.forEach(event => {
                if (cat.findIndex(category => category === event.category) == -1)
                    cat.push(event.category);
            })
            res.render('./events/connections', { events, cat });
        })
        .catch(err => next(err));
};

//GET /events/new: send html form to create a new event
exports.new = (req, res) => {
    res.render('./events/newConnection');
};

//POST /events: Create a new event
exports.create = (req, res, next) => {
    let event = new model(req.body);
    event.creator = req.session.user;
    event.save()
        .then(event => {
        req.flash('success', 'Tournament created successfully');
            res.redirect('/events');
        })
        .catch(err => {
            if (err.name === 'ValidationError') {
                err.status = 400;
                req.flash('error', err.message);
                return res.redirect('back');
            }
            next(err);
        });

};

//GET /events/:id: Details of a event identified by id
exports.show = (req, res, next) => {
    model.findById(req.params.id).populate('creator', user)
        .then(event => {
            if (event) {
                let rsvpSize = 0;
                rsvp.find({ eventID: req.params.id, status: "YES" })
                    .then(rsvpConnections => {
                        if (rsvpConnections) rsvpSize = rsvpConnections.length;
                        res.render('./events/connection', { event, rsvpSize });
                    })
                    .catch(err => next(err));
            } else {
                let err = new Error("SHOW_DETAILS: Cannot find a event with id " + req.params.id);
                err.status = 404;
                next(err);

            }
        })
        .catch(err => next(err));

};

//GET /events/:id/edit: send html form for editing an existing event
exports.edit = (req, res, next) => {
    let id = req.params.id
    model.findById(id)
        .then(event => {
            if (event) {
                res.render('./events/editConnection', { event });
            } else {
                let err = new Error("Cannot find a event with id " + id)
                err.status = 404;
                next(err);
            }
        })
        .catch(err => next(err));

};

//PUT /events/:id: update the event identified by id
exports.update = (req, res, next) => {
    let id = req.params.id;
    let event = req.body;
    model.findByIdAndUpdate(req.params.id, event, { useFindAndModify: false, runValidators: true })
        .then(event => {
            if (event) {
                req.flash('success', 'Event updated successfully');
                res.redirect('/events/' + req.params.id);
            }
            else {
                let err = new Error("Cannot find a event with id " + req.params.id);
                err.status = 404;
                next(err);
            }

        })
        .catch(err => {
            if (err.name === 'ValidationError') {
                req.flash('error', err.message);
                err.status = 400;
                return res.redirect('back');
            }
            next(err);
        });
};

//DELETE /events/:id: delete the event identified by id
exports.delete = (req, res, next) => {
    let id = req.params.id;
    model.findByIdAndDelete(id, { useFindAndModify: false })
        .then(event => {
            if (event) {

                rsvp.deleteMany({ eventID: req.params.id })
                    .then(tournamentInfo => {
                        req.flash('success', 'Event deleted successfully');
                        res.redirect('/events');
                    })
                    .catch(err => next(err));
            } else {
                let err = new Error("DELETE_ERROR: Cannot find a event with id " + req.params.id);
                err.status = 404;
                next(err);
            }

        })
        .catch(err => next(err));
};


exports.CreateRSVP = (req, res, next) => {
    let status = req.body.status.toUpperCase();
    rsvp.find({ eventID: req.params.id, userID: req.session.user })
        .then(rsvpInfo => {
            if (rsvpInfo.length == 1) {
                rsvpInfo[0].status = status;
                rsvp.findByIdAndUpdate(rsvpInfo[0]._id, rsvpInfo[0], { useFindAndModify: false, runValidators: true })
                    .then(rsvpObj => {
                        if (rsvpObj) {
                            req.flash('success', 'Successfully updated RSVP for this event');
                            res.redirect('/users/profile');
                        }
                        else {
                            let err = new Error("Unable to update RSVP for the event");
                            err.status = 404;
                            next(err);
                        }
                    })
                    .catch(err => next(err));
            }
            else {
                let rsvpObj = new rsvp();
                rsvpObj.status = status;
                rsvpObj.userID = req.session.user;
                rsvpObj.eventID = req.params.id;
                rsvpObj.save()
                    .then(rsvpInfo => {
                        req.flash('success', 'Successfully created RSVP for this event');
                        res.redirect('/users/profile');
                    })
                    .catch(err => next(err));
            }
        })
        .catch(err => next(err));
};

exports.DeleteRSVP = (req, res, next) => {
    rsvp.deleteOne({ eventID: req.params.id, userID: req.session.user })
        .then(rsvpInfo => {
            if (rsvpInfo) {
                req.flash("success", "RSVP deleted successfully");
                res.redirect("/users/profile");
            }
        })
        .catch(err => next(err));
}