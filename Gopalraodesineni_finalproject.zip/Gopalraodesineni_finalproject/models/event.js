const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const eventSchema = new Schema({
    title: {type: String, required: [true, 'title is required']},
    category: {type: String, required: [true, 'category is required']},
    details: {type: String, required: [true, 'details is required'], 
                minLength: [10, 'The details should have atleast 10 characters']},
    hostname: {type: String, required: [true, 'hostname is required']},
    emailID: {type: String, required: [true, 'Email ID is required']},
    startDate: {type: String, required: [true, 'Start Date is required']},
    endDate: {type: String, required: [true, 'End Date is required']},
    location: {type: String, required: [true, 'location is required']},
    img: {type: String, required: [true, 'Event Logo is required']},
    creator: {type: Schema.Types.ObjectId, ref: 'User'}
},
{timestamps:true}
);

//collection name is events(plural to model name)
module.exports = mongoose.model('event', eventSchema);








